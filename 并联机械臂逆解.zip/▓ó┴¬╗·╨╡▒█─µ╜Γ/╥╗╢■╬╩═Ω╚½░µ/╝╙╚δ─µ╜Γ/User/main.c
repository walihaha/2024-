#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "control.h"
#include "servo_control.h"

#define MAX_QUEUE_SIZE 16

uint8_t KeyNum;          // 定义用于接收键码的变量
extern uint8_t Key_GetNum(void); // 获取键码函数声明
float Angle_1 = 102, Angle_2 = 130, Angle_3 = 12; // 初始化角度变量1dizuo  2dabi   3xiaobi
float x = 0.0, y = 6.0, z = 5.0;

typedef void (*ControlFunc)(void);

// 队列结构
typedef struct {
    ControlFunc queue[MAX_QUEUE_SIZE];
    int front;
    int rear;
    int size;
} CommandQueue;

CommandQueue cmdQueue = {.front = 0, .rear = -1, .size = 0};

// 添加指令到队列
void Enqueue(CommandQueue* q, ControlFunc func) {
    if (q->size < MAX_QUEUE_SIZE) {
        q->rear = (q->rear + 1) % MAX_QUEUE_SIZE;
        q->queue[q->rear] = func;
        q->size++;
    }
}

// 执行队列中的所有指令
void ExecuteQueue(CommandQueue* q) {
    while (q->size > 0) {
        ControlFunc func = q->queue[q->front];
        q->front = (q->front + 1) % MAX_QUEUE_SIZE;
        q->size--;
        func();
    }
}

void (*KeyControlFuncs[9])(void) = {control_1, control_2, control_3, control_4, control_5, control_6, control_7, control_8, control_9};
void (*KeySelectFuncs[10])(void) = {selecthei_1, selecthei_2, selecthei_3, selecthei_4, selecthei_5, selectbai_1, selectbai_2, selectbai_3, selectbai_4, selectbai_5};

const char* SelectOptions[10] = {"selecthei_1", "selecthei_2", "selecthei_3", "selecthei_4", "selecthei_5", "selectbai_1", "selectbai_2", "selectbai_3", "selectbai_4", "selectbai_5"};
const char* ControlOptions[9] = {"control_1", "control_2", "control_3", "control_4", "control_5", "control_6", "control_7", "control_8", "control_9"};

typedef enum {
    STATE_SELECT_HEI_BAI,
    STATE_SELECT_CONTROL,
    STATE_EXECUTE_QUEUE
} State;

State currentState = STATE_SELECT_HEI_BAI;
int selectedIndex = 0;

void DisplayStaticStrings(void) {
    OLED_ShowString(4, 1, "KeyNum:");
}

void UpdateDisplay(void) {
//    OLED_ShowSignedNum(1, 3, x, 3);	// OLED显示角度变量
//    OLED_ShowSignedNum(2, 3, y, 3);
//    OLED_ShowSignedNum(3, 3, z, 3);
}

void DisplaySelection(void) {
    if (currentState == STATE_SELECT_HEI_BAI) {
        OLED_ShowString(5, 1, "Select HEI/BAI:");
        OLED_ShowString(6, 1, (char*)SelectOptions[selectedIndex]);
    } else if (currentState == STATE_SELECT_CONTROL) {
        OLED_ShowString(5, 1, "Select Control:");
        OLED_ShowString(6, 1, (char*)ControlOptions[selectedIndex]);
    }
}

void SelectHeiBai(void) {
    currentState = STATE_SELECT_HEI_BAI;
    selectedIndex = 0;
    DisplaySelection();
    
    while (currentState == STATE_SELECT_HEI_BAI) {
        KeyNum = Key_GetNum(); // 获取按键键码
        
        if (KeyNum == 1) { // 增加选项
            selectedIndex = (selectedIndex + 1) % 10;
        }else if (KeyNum == 13) { // 增加选项
            selectedIndex = (selectedIndex + 1) % 10; 
        }else if (KeyNum == 2) { // 减少选项
            selectedIndex = (selectedIndex - 1 + 10) % 10;
        }else if (KeyNum == 14) { // 减少选项
            selectedIndex = (selectedIndex - 1 + 10) % 10;
        }else if (KeyNum == 16) { // 确认选择
            Enqueue(&cmdQueue, KeySelectFuncs[selectedIndex]);
            currentState = STATE_SELECT_CONTROL;
            selectedIndex = 0;
            DisplaySelection();
        }else if (KeyNum == 4) { // 确认选择
            Enqueue(&cmdQueue, KeySelectFuncs[selectedIndex]);
            currentState = STATE_SELECT_CONTROL;
            selectedIndex = 0;
            DisplaySelection();
        }else if (KeyNum == 15) { // 特定按键触发队列执行
            currentState = STATE_EXECUTE_QUEUE;
        }else if (KeyNum == 3) { // 特定按键触发队列执行
            currentState = STATE_EXECUTE_QUEUE;
        }

        DisplaySelection();
        Delay_ms(200); // 防止按键抖动
    }
}

void SelectControl(void) {
    currentState = STATE_SELECT_CONTROL;
    selectedIndex = 0;
    DisplaySelection();

    while (currentState == STATE_SELECT_CONTROL) {
        KeyNum = Key_GetNum(); // 获取按键键码
        
        if (KeyNum == 1) { // 增加选项
            selectedIndex = (selectedIndex + 1) % 9;
        } else if (KeyNum == 13) { // 增加选项
            selectedIndex = (selectedIndex + 1) % 9;
        }else if (KeyNum == 2) { // 减少选项
            selectedIndex = (selectedIndex - 1 + 9) % 9;
        }else if (KeyNum == 14) { // 减少选项
            selectedIndex = (selectedIndex - 1 + 9) % 9; 
        }else if (KeyNum == 16) { // 确认选择
            Enqueue(&cmdQueue, KeyControlFuncs[selectedIndex]);
            selectedIndex = 0; // Reset index to allow selection of multiple commands
            DisplaySelection();
            SelectHeiBai();
        }else if (KeyNum == 4) { // 确认选择
            Enqueue(&cmdQueue, KeyControlFuncs[selectedIndex]);
            selectedIndex = 0; // Reset index to allow selection of multiple commands
            DisplaySelection();
            SelectHeiBai();
        }else if (KeyNum == 15) { // 特定按键触发队列执行
            currentState = STATE_EXECUTE_QUEUE;
        }
          else if (KeyNum == 3) { // 特定按键触发队列执行
            currentState = STATE_EXECUTE_QUEUE;
        }
        DisplaySelection();
        Delay_ms(150); // 防止按键抖动
    }
}

int main(void) {
    /* 模块初始化 */
    OLED_Init();        // OLED初始化
    Servo_Init();       // 舵机初始化
    KEY_4x4_Init();     // 按键初始化
    Servo_Initqibeng(); // 其他初始化

    /* 显示静态字符串 */
    DisplayStaticStrings();
    
    while (1) {		
        if (currentState == STATE_SELECT_HEI_BAI) {
            SelectHeiBai();
        } else if (currentState == STATE_SELECT_CONTROL) {
            SelectControl();
        } else if (currentState == STATE_EXECUTE_QUEUE) {
            ExecuteQueue(&cmdQueue);
            currentState = STATE_SELECT_HEI_BAI; // 执行完队列后返回初始状态
        }
        
        // 更新显示
        UpdateDisplay();
    }
}
