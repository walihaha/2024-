#ifndef __KEY_H
#define __KEY_H

#define   C1        GPIO_Pin_7   
#define   C2        GPIO_Pin_6     
#define   C3        GPIO_Pin_5      
#define   C4        GPIO_Pin_4     
#define   R1        GPIO_Pin_3     
#define   R2        GPIO_Pin_2    
#define   R3        GPIO_Pin_1     
#define   R4        GPIO_Pin_0    

#define   RC(x)      GPIO_ReadInputDataBit(GPIOC,x) 
 

void KEY_4x4_Init(void);

#endif



/*********
 R1 A3
 R2 A2
 R3 A1
 R4 A0
 
 C1 A7
 C2 A6
 C3 A5
 C4 A4
 A->C




*******************/
