// control.h
#ifndef CONTROL_H
#define CONTROL_H

#include <math.h>

// ????
#define BASE_HEIGHT 6.5  // ????,??cm
#define ARM1_LENGTH 9.4  // ????,??cm
#define ARM2_LENGTH 8.6  // ????,??cm
#define ARM_COMPENSATION 6.4
#define HEIGHT_COMPENSATION 5.3
#define SERVO_MAX_PWM 2000 // ??????????PWM?
#define SERVO_MIN_PWM 1000 // ??????????PWM?

// ??????
void servo_control(int base_port, int arm1_port, int arm2_port, float base_angle, float arm1_angle, float arm2_angle);

// ???????
void robotic_arm_inverse_kinematics(float x, float y, float z);

// ???????????
void set_servo_angle(int port, float angle);

float duoji1(float x, float y, float z);
float xzguding(float x, float y, float z);
float zbian(float x, float y, float z);
void up();
void down();
void control_1();
void control_2();
void control_3();
void control_4();
void control_5();
void control_6();
void control_7();
void control_8();
void control_9();
void selectbai_1();
void selectbai_2();
void selectbai_3();
void selectbai_4();
void selectbai_5();
void selecthei_1();
void selecthei_2();
void selecthei_3();
void selecthei_4();
void selecthei_5();
//void famengkongzhi();
#endif // CONTROL_H
