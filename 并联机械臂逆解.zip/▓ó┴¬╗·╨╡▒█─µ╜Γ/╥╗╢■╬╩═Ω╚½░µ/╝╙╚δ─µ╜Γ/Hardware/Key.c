#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "key.h"


/**
  * 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
u8 anxian = 0;  //anxian这个变量为1时，证明有按钮正在被按下
  
void KEY_4x4_Init(void)     //键盘IO口配置及初始化
{
 	GPIO_InitTypeDef GPIO_InitStructure;       	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);      
	//使用GPIOC的0,1,2,3引脚为行 R1~R4对应矩形按钮的5,6,7,8引脚
	GPIO_InitStructure.GPIO_Pin  = R1|R2|R3|R4;  
   //行  0123
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     //使用推挽输出
    GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC,R1|R2|R3|R4);   
//令GPIO的0,1,2,3引脚输出为1
	/********************************************************************/
	/********************************************************************/
	/********************************************************************/
	GPIO_InitStructure.GPIO_Pin  = C1|C2|C3|C4;         
//使用GPIOA的4,5,6,7引脚为列  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;        //使用上拉输入
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, C1|C2|C3|C4);	
//令GPIO的4,5,6,7引脚输出为1	
}

uint8_t Key_GetNum(void)
{	 
    uint8_t KeyNum = 0;	
	GPIO_Write(GPIOC,0x00fe); 
	if((RC(C4)==0)||(RC(C3)==0)||(RC(C2)==0)||(RC(C1)==0))   
	{
		Delay_ms(10);  
		
		if(RC(C4) ==0)   
		{
			anxian = 1;    
			KeyNum = 1;   
			while(!RC(C4));   
				//当按钮处于被按下的状态的时候，程序一直卡在循环读取按钮的状态，避免多按钮同时按下时读取错误
		}
		else if(RC(C3)==0)
		{
			anxian = 1;
			KeyNum = 2;
			while(!RC(C3));
		}
		else if(RC(C2)==0)
		{
			anxian = 1;
			KeyNum = 3;
			while(!RC(C2));
		}
		else if(RC(C1)==0)
		{
	    	anxian = 1;
			KeyNum = 4;
			while(!RC(C1));
		}
		else  //如果第一行四列中没有按钮被按下
		{
			anxian = 0;
			GPIO_Write(GPIOC,0x00ff);
		}
	}//第一行判断完成，这是我们判断第二行
	GPIO_Write(GPIOC,0x00fd);    //第二行         
	if((RC(C4)==0)||(RC(C3)==0)||(RC(C2)==0)||(RC(C1)==0))
	{
		Delay_ms(10);
		if(RC(C4)==0)
		{
			anxian = 1;
			KeyNum = 5;
			while(!RC(C4));
		}
		else if(RC(C3)==0)
		{
	     	anxian = 1;
			KeyNum = 6;
			while(!RC(C3));
		}
		else if(RC(C2)==0)
		{
	    	anxian = 1;
			KeyNum = 7;
			while(!RC(C2));
		}
		else if(RC(C1)==0)
		{	 
	    	anxian = 1;
			KeyNum = 8;
			while(!RC(C1));
		}
		else 
		{
			anxian = 0;
			GPIO_Write(GPIOC,0x00ff);
		}
	}
	GPIO_Write(GPIOC,0x00fb);//第三行
	if((RC(C4)==0)||(RC(C3)==0)||(RC(C2)==0)||(RC(C1)==0))
	{
		Delay_ms(10);
		if(RC(C4)==0)
		{
			anxian = 1;
			KeyNum = 9;
			while(!RC(C4));
		}
		else if(RC(C3)==0)
		{
	     	anxian = 1;
			KeyNum = 10;
			while(!RC(C3));
		}
		else if(RC(C2)==0)
		{
	    	anxian = 1;
			KeyNum = 11;
			while(!RC(C2));
		}
		else if(RC(C1)==0)
		{
	    	anxian = 1;
			KeyNum = 12;
			while(!RC(C1));
		}
		else 
		{
			anxian = 0;
			GPIO_Write(GPIOC,0x00ff);
		}
	}
	GPIO_Write(GPIOC,0x00f7);//第四行
	if((RC(C4)==0)||(RC(C3)==0)||(RC(C2)==0)||(RC(C1)==0))
	{
		Delay_ms(10);
		if(RC(C4)==0)
		{
			anxian = 1;
			KeyNum = 13;
			while(!RC(C4));
		}
		else if(RC(C3)==0)
		{
	     	anxian = 1;
			KeyNum = 14;
			while(!RC(C3));
		}
		else if(RC(C2)==0)
		{
	    	anxian = 1;
			KeyNum = 15;
			while(!RC(C2));
		}
		else if(RC(C1)==0)
		{
	    	anxian = 1;
			KeyNum = 16;
			while(!RC(C1));
		}
		else 
		{
			anxian = 0;
			GPIO_Write(GPIOC,0x00ff);
		}
	}
	return KeyNum;	
}
