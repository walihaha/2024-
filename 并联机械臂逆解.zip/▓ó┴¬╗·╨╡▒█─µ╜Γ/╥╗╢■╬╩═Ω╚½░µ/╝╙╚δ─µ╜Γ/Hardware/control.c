// control.c
#include "control.h"
#include "stm32f10x.h"  
#include "Servo.h"
#include "servo_control.h"
#include "Delay.h"
#define RAD_TO_DEG (180.0 / 3.1415926)
#define shudu 39

float rad_to_deg(float rad) {
    return rad * RAD_TO_DEG;
}

// ??????
void servo_control(int base_port, int arm1_port, int arm2_port, float base_angle, float arm1_angle, float arm2_angle) {
    // ?????????set_servo_angle????????,????PWM??
   	Servo_SetAngle1(base_angle+90+12);
		Servo_SetAngle2(arm1_angle+40);
		Servo_SetAngle3(201-arm2_angle);
}//���Լ�����ĽǶȲ���

// ???????
float duoji1(float x, float y, float z){

 float angle = atan2(y, x) * 180 / 3.1415926;  // ????(-180?180????)

    // ??????0?180????
    if (angle < 0) {
        angle += 360;  // ???0?360????
    }

    if (angle > 180) {
        angle = 360 - angle;  // ???0?180????
    }

    return angle;
}



			
float zbian(float x, float y, float z){

return 0;
}

	void robotic_arm_inverse_kinematics(float x, float y, float z) {
		float base_angle, arm1_angle, arm2_angle;
    float projection, short_side, hypotenuse;
    float arm1_angle_part1, arm1_angle_part2;
    float adjusted_x, adjusted_y, adjusted_z;

    // Adjust coordinates
    adjusted_y = y +5.5;
    adjusted_z = z + HEIGHT_COMPENSATION + adjusted_y * 0.1;
    adjusted_x = x * (1.16 - adjusted_y * 0.01);

    // Calculate base angle
    base_angle = atan(adjusted_x / adjusted_y);

    // Calculate arm angles
    projection = sqrt(adjusted_x * adjusted_x + adjusted_y * adjusted_y) - ARM_COMPENSATION;
    short_side = fabs(BASE_HEIGHT - adjusted_z);
    hypotenuse = sqrt(short_side * short_side + projection * projection);

    arm1_angle_part1 = acos((ARM1_LENGTH * ARM1_LENGTH + hypotenuse * hypotenuse - ARM2_LENGTH * ARM2_LENGTH) / (2 * ARM1_LENGTH * hypotenuse));
    if (BASE_HEIGHT == adjusted_z) {
        arm1_angle_part2 = 0;
    } else if (BASE_HEIGHT > adjusted_z) {
        arm1_angle_part2 = atan(projection / short_side) - 3.1415926 / 3;
    } else {
        arm1_angle_part2 = atan(short_side / projection);
    }
    arm1_angle = arm1_angle_part1 + arm1_angle_part2;

    arm2_angle = acos((ARM1_LENGTH * ARM1_LENGTH + ARM2_LENGTH * ARM2_LENGTH - hypotenuse * hypotenuse) / (2 * ARM1_LENGTH * ARM2_LENGTH)) + arm1_angle;

    // Convert angles from radians to degrees
    base_angle = rad_to_deg(base_angle);
    arm1_angle = rad_to_deg(arm1_angle);
    arm2_angle = rad_to_deg(arm2_angle);

    // Control servos with calculated angles
    servo_control(1, 2, 0, base_angle, arm1_angle, arm2_angle);
	}
void up(){
      
        Servo_Write(SERVO_PUMP, 180);
	      Delay_ms(1000);
        Servo_Write(SERVO_PUMP, 0);
}
void down(){

        
        Servo_Write(SERVO_VALVE, 180);
	      Delay_ms(500);
	      Servo_Write(SERVO_VALVE, 0);
 
}
void control_1()
{      
		 for(float x=0;x>=-4.25;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
		 for(float y=6;y<=8.5;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.25,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=4;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.25,8.5,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=4;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.25,8.5,z);
			 Delay_ms(shudu);
		 };
		 for(float y=8.5;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-4.25;x<=0;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
}
void control_2()
{      
     for(float y=6;y<=9;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(0,y,7);
			 Delay_ms(shudu);
		 };
	   for(float z=7;z>=4;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(0,9,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=4;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(0,9,z);
			 Delay_ms(shudu);
		 };
		 for(float y=9;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(0,y,7);
			 Delay_ms(shudu);
		 };
}
void control_3()
{      
	for(float x=0;x<=4.75;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };	 
	for(float y=6;y<=8.75;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(4.75,y,7);
			 Delay_ms(40);
		 };
     for(float z=7;z>=4;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(4.75,8.75,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=4;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(4.75,8.75,z);
			 Delay_ms(shudu);
		 };
		 for(float y=8.75;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(4.75,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=4.75;x>=0;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };	 
}
void control_4()
{    
     for(float x=0;x>=-4.5;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
		 for(float y=6;y<=11.25;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.5,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=3.5;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.5,11.25,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=3.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.5,11.25,z);
			 Delay_ms(shudu);
		 };
		 for(float y=11.25;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-4.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-4.5;x<=0;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
}
void control_5()
{      
		 for(float y=6;y<=11.75;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.25,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=3.5;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.25,11.75,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 down();
		 Delay_ms(100);
		 for(float z=3.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.25,11.75,z);
			 Delay_ms(shudu);
		 };
		 for(float y=11.75;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(0,y,7);
			 Delay_ms(shudu);
		 };
}
void control_6()
{      
		 for(float x=0;x<=4;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
	   for(float y=6;y<=11.5;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(4,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=3;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(4,11.5,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=3;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(4,11.5,z);
			 Delay_ms(shudu);
		 };
		 for(float y=11.5;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(4,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=4;x>=0;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
}
void control_7()
{      
	   for(float x=0;x>=-5;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };	 
	   for(float y=6;y<=13.75;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-5,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=3;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-5,13.75,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=3;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-5,13.75,z);
			 Delay_ms(shudu);
		 };
		 for(float y=13.75;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-5;x<=0;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };	 
}
void control_8()
{      
		 for(float y=6;y<=14.25;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.5,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=2.75;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.5,14.25,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=2.75;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-0.5,14.25,z);
			 Delay_ms(shudu);
		 };
		 for(float y=14.25;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(0  ,y,7);
			 Delay_ms(shudu);
		 };
}
void control_9()
{      
		 for(float x=0;x<=3.5;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
	   for(float y=6;y<=14.5;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(3.5,y,7);
			 Delay_ms(shudu);
		 };
     for(float z=7;z>=2.5;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(3.5,14.5,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
			down();
			Delay_ms(100);
		 for(float z=2.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(3.5,14.5,z);
			 Delay_ms(shudu);
		 };
		 for(float y=14.5;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(3.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=3.5;x>=0;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
}
void selecthei_1()
{ 
	for(float x=0;x>=-9.5;x=x-0.25)
	{
		robotic_arm_inverse_kinematics(x,6,7);
		Delay_ms(shudu);
	};
	   for(float y=6;y<=4.5;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-9.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=2.2;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-9.5,4.5,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=3;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-9.5,4.5,z);
			 Delay_ms(shudu);
		 };
		 for(float y=4.5;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-9.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-9.5;x<=0;x=x+0.25)
	{
		robotic_arm_inverse_kinematics(x,6,7);
		Delay_ms(shudu);
	};
}
void selecthei_2()
{ 
	for(float x=0;x>=-10.25;x=x-0.25)
	{
		robotic_arm_inverse_kinematics(x,6,7);
		Delay_ms(shudu);
	};
	   for(float y=6;y<=7.25;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=2.2;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,7.25,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=3;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,7.25,z);
			 Delay_ms(shudu);
		 };
		 for(float y=7.25;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-10.25;x<=0;x=x+0.25)
	{
		robotic_arm_inverse_kinematics(x,6,7);
		Delay_ms(shudu);
	};
}
void selecthei_3()
{ 
  for(float x=0;x>=-10;x=x-0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
	for(float y=6;y<=10.25;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=2.1;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10,10.25,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=2.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10,10.25,z);
			 Delay_ms(shudu);
		 };
		 for(float y=10.25;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-10;x<=0;x=x+0.25)
	   {
		 robotic_arm_inverse_kinematics(x,6,7);
			 Delay_ms(shudu);
		 };
	 }
void selecthei_4()
{ 
     for(float x=0;x>=-10.25;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
	   for(float y=6;y<=13;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,y,7);
			 Delay_ms(shudu);
		 };
	   for(float z=7;z>=1.0;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,13,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=1.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,13,z);
			 Delay_ms(shudu);
		 };
		 for(float y=13;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-10.25;x<=0;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
}
void selecthei_5()
{ 
     for(float x=0;x>=-10.5;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
	   for(float y=6;y<=15;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.5,y,7);
			 Delay_ms(shudu);
		 };
	   for(float z=7;z>=0;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.5,15,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=0.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.5,15,z);
			 Delay_ms(shudu);
		 };
		 for(float y=15;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(-10.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=-10.5;x<=0;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
}
void selectbai_1()
{ 
	   for(float x=0;x<=10.25;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,5.25,7);
		  Delay_ms(shudu);
	   };
		 for(float z=7;z>=2.2;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(10.25,5.25,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=2.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(10.25,5.25,z);
			 Delay_ms(shudu);
		 };
		 for(float x=10.25;x>=0;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
	 }
void selectbai_2()
{ 
	   for(float x=0;x<=9.5;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
	   for(float y=6;y<=8.75;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(9.5,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=2.2;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(9.5,8.75,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=2.5;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(9.5,8.75,z);
			 Delay_ms(shudu);
		 };
		 for(float y=8.75;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(9.5,y,7);
			 Delay_ms(40);
		 };
		 for(float x=9.5;x>=0;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
	 }
void selectbai_3()
{ 
	   for(float x=0;x<=9.25;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
     for(float y=6;y<=11.5;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(9.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=1.2;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(9.25,11.5,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=2;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(9.25,11.5,z);
			 Delay_ms(shudu);
		 };
		 for(float y=11.5;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(9.25,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=9.25;x>=0;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
}
void selectbai_4()
{ 
     for(float x=0;x<=9;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
     for(float y=6;y<=13.75;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(9,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=0.5;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(9,13.75,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=1;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(9,13.75,z);
			 Delay_ms(shudu);
		 };
		 for(float y=13.75;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(9,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=9;x>=0;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
}
void selectbai_5()
{ 
     for(float x=0;x<=9;x=x+0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
     for(float y=6;y<=16;y=y+0.25)
	   {
		 robotic_arm_inverse_kinematics(9,y,7);
			 Delay_ms(shudu);
		 };
		 for(float z=7;z>=0;z=z-0.25)
	   {
		 robotic_arm_inverse_kinematics(9,16,z);
			 Delay_ms(shudu);
		 };
		 Delay_ms(400);
		 up();
		 Delay_ms(200);
		 for(float z=0;z<=7;z=z+0.25)
	   {
		 robotic_arm_inverse_kinematics(9,16,z);
			 Delay_ms(shudu);
		 };
		 for(float y=16;y>=6;y=y-0.25)
	   {
		 robotic_arm_inverse_kinematics(9,y,7);
			 Delay_ms(shudu);
		 };
		 for(float x=9;x>=0;x=x-0.25)
	   {
		  robotic_arm_inverse_kinematics(x,6,7);
		  Delay_ms(shudu);
	   };
}
void removecentre()
{
	robotic_arm_inverse_kinematics(0,6,7);
}
void remove(float Angle_1,float Angle_2,float Angle_3)
{
	    Servo_SetAngle1(10);
      Servo_SetAngle2(130);
      Servo_SetAngle3(20);
}
// ???????????

