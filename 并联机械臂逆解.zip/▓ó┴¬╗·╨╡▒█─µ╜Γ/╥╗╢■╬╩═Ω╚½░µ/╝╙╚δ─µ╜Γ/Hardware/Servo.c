#include "stm32f10x.h"                  // Device header
#include "PWM.h"

/**
  * 函    数：舵机初始化
  * 参    数：无
  * 返 回 值：无
  */
void Servo_Init(void)
{
	PWM_Init();									//初始化舵机的底层PWM
}

/**
  * 函    数：舵机设置角度
  * 参    数：Angle 要设置的舵机角度，范围：0~180
  * 返 回 值：无
  */
void Servo_SetAngle1(float Angle_1)
{
	
	PWM_SetCompare1(Angle_1 / 180 * 2000 + 500);		
}
void Servo_SetAngle2(float Angle_2)
{
//	if(Angle_2>140){
//	Angle_2=140;
//	}
//	if(Angle_2<60){
//	Angle_2=60;
//	}
	PWM_SetCompare2(Angle_2 / 180 * 2000 + 500);		
}
void Servo_SetAngle3(float Angle_3)
{
//	if(Angle_3>55){
//	Angle_3=55;
//	}
//	if(Angle_3<15){
//	Angle_3=15;
//	}
	PWM_SetCompare3(Angle_3 / 180 * 2000 + 500);		
}
void Servo_SetAngle4(float Angle_4)
{
	PWM_SetCompare4(Angle_4 / 180 * 1000 + 1000);		
}
