#ifndef __SERVO_CONTROL_H
#define __SERVO_CONTROL_H

#include "stm32f10x.h"

#define SERVO_PUMP   0
#define SERVO_VALVE  1

void Servo_Initqibeng(void);
void Servo_Write(uint8_t servo, uint8_t angle);
void up(void);
void down(void);

#endif
